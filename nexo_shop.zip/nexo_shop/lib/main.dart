import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';
import 'screens/home_screen.dart';
import 'screens/admin_panel_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Nexo Shop',
      theme: ThemeData(
        fontFamily: 'Vazir',
        primarySwatch: Colors.deepPurple,
        scaffoldBackgroundColor: Color(0xFFF5F1FF),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          iconTheme: IconThemeData(color: Colors.deepPurple),
          titleTextStyle: TextStyle(
            fontFamily: 'Vazir',
            fontSize: 24,
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
          elevation: 0,
          centerTitle: true,
        ),
      ),
      initialRoute: '/',
      routes: {
        '/': (_) => const SplashScreen(),
        '/admin': (_) => const AdminPanelScreen(),
      },
      // onGenerateRoute تا اگر route نداشت خطا نده و home باز شه
      onGenerateRoute: (settings) {
        return MaterialPageRoute(builder: (_) => const HomeScreen());
      },
    );
  }
}

final List<Map<String, String>> appCategories = [
  {'title': 'گوشی', 'icon': 'assets/images/phone.png'},
  {'title': 'هدفون', 'icon': 'assets/images/headphone.png'},
  {'title': 'ساعت', 'icon': 'assets/images/watch.png'},
  {'title': 'کنسول', 'icon': 'assets/images/console.png'},
];

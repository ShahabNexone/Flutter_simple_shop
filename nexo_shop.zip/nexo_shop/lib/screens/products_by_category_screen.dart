import 'package:flutter/material.dart';
import 'dart:io';
import '../db/database_helper.dart';
import '../models/product.dart';
import 'product_detail_screen.dart';

class ProductsByCategoryScreen extends StatefulWidget {
  final String categoryTitle;
  const ProductsByCategoryScreen({Key? key, required this.categoryTitle}) : super(key: key);

  @override
  State<ProductsByCategoryScreen> createState() => _ProductsByCategoryScreenState();
}

class _ProductsByCategoryScreenState extends State<ProductsByCategoryScreen> {
  List<Product> products = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  Future<void> _loadProducts() async {
    setState(() => isLoading = true);
    products = await DatabaseHelper().getProducts(categoryTitle: widget.categoryTitle);
    setState(() => isLoading = false);
  }

  @override
  void didUpdateWidget(covariant ProductsByCategoryScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.categoryTitle != oldWidget.categoryTitle) {
      _loadProducts();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(widget.categoryTitle, style: TextStyle(color: Colors.black)),
        iconTheme: IconThemeData(color: Colors.black),
        elevation: 0,
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : (products.isEmpty
          ? Center(
        child: Text(
          'محصولی در این دسته ثبت نشده.\nبرای افزودن محصول جدید به پنل ادمین بروید.',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 18, color: Colors.grey[700]),
        ),
      )
          : ListView.builder(
        padding: const EdgeInsets.all(20),
        itemCount: products.length,
        itemBuilder: (context, index) {
          final p = products[index];
          return GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ProductDetailScreen(product: p),
                ),
              );
            },
            child: Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              elevation: 3,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Image.file(
                      File(p.imagePath),
                      height: 56,
                      errorBuilder: (context, error, stackTrace) {
                        return const Icon(Icons.image_not_supported);
                      },
                    ),
                    const SizedBox(width: 20),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(p.name, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                          const SizedBox(height: 8),
                          Text('${p.price.toString()} تومان', style: TextStyle(color: Colors.blue, fontSize: 16)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      )),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.refresh),
        onPressed: _loadProducts,
        tooltip: 'بارگذاری مجدد',
      ),
    );
  }
}

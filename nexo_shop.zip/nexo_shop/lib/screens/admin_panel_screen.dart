import 'package:flutter/material.dart';
import '../data/app_categories.dart';
import 'product_form_screen.dart';
import '../db/database_helper.dart';
import '../models/product.dart';

class AdminPanelScreen extends StatefulWidget {
  const AdminPanelScreen({Key? key}) : super(key: key);

  @override
  State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

class _AdminPanelScreenState extends State<AdminPanelScreen> {
  List<Product> products = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  Future<void> _loadProducts() async {
    setState(() => isLoading = true);
    products = await DatabaseHelper().getProducts();
    setState(() => isLoading = false);
  }

  Future<void> _gotoAddProduct() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProductFormScreen(),
      ),
    );
    if (result == true) {
      _loadProducts();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('پنل ادمین'),
        actions: [
          IconButton(
            icon: Icon(Icons.add_circle_outline),
            tooltip: 'افزودن محصول',
            onPressed: _gotoAddProduct,
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: products.length,
        itemBuilder: (context, i) {
          final p = products[i];
          final cat = appCategories.firstWhere(
                (cat) => cat['title'] == p.categoryTitle,
            orElse: () => appCategories[0],
          );
          return Card(
            margin: const EdgeInsets.only(bottom: 18),
            child: ListTile(
              leading: cat['icon'] != null
                  ? Image.asset(cat['icon']!, height: 32)
                  : null,
              title: Text(p.name),
              subtitle: Text('${p.price} تومان - ${p.categoryTitle}'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: Icon(Icons.edit),
                    onPressed: () async {
                      final result = await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ProductFormScreen(product: p, isEdit: true),
                        ),
                      );
                      if (result == true) _loadProducts();
                    },
                  ),
                  IconButton(
                    icon: Icon(Icons.delete_outline),
                    onPressed: () async {
                      await DatabaseHelper().deleteProduct(p.id!);
                      _loadProducts();
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
